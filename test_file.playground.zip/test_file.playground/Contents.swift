//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        let label1 = UILabel()
        label1.frame = CGRect(x: 140, y: 240, width: 200, height: 20)
        label1.text = "WWDC2020"
        label1.textColor = .black
    
        view.addSubview(label)
        view.addSubview(label1)

        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
